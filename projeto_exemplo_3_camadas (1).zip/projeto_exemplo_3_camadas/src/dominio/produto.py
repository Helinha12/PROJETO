from dataclasses import dataclass
from typing import Optional


@dataclass
class Produto:
    """Representa a entidade de dominio Produto."""

    id: Optional[int]
    nome: str
    preco: float
