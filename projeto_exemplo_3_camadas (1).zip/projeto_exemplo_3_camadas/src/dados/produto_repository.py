from typing import Optional

import mysql.connector

from dominio.produto import Produto


class ProdutoRepository:
    """Camada data: faz o acesso ao banco e executa SQL."""

    def __init__(self, conexao: mysql.connector.MySQLConnection) -> None:
        self.conexao = conexao
        self._criar_tabela()

    def _criar_tabela(self) -> None:
        sql = """
        CREATE TABLE IF NOT EXISTS produtos (
            id INT NOT NULL AUTO_INCREMENT,
            nome VARCHAR(255) NOT NULL,
            preco DECIMAL(10,2) NOT NULL,
            PRIMARY KEY (id)
        )
        """
        cursor = self.conexao.cursor()
        cursor.execute(sql)
        self.conexao.commit()
        cursor.close()

    def adicionar(self, produto: Produto) -> int:
        cursor = self.conexao.cursor()
        cursor.execute(
            "INSERT INTO produtos (nome, preco) VALUES (%s, %s)",
            (produto.nome, produto.preco),
        )
        self.conexao.commit()
        novo_id = int(cursor.lastrowid)
        cursor.close()
        return novo_id

    def listar_todos(self) -> list[Produto]:
        cursor = self.conexao.cursor(dictionary=True)
        cursor.execute(
            "SELECT id, nome, preco FROM produtos ORDER BY id"
        )
        linhas = cursor.fetchall()
        cursor.close()
        return [
            Produto(id=linha["id"], nome=linha["nome"], preco=float(linha["preco"]))
            for linha in linhas
        ]

    def buscar_por_id(self, id_produto: int) -> Optional[Produto]:
        cursor = self.conexao.cursor(dictionary=True)
        cursor.execute(
            "SELECT id, nome, preco FROM produtos WHERE id = %s",
            (id_produto,),
        )
        linha = cursor.fetchone()
        cursor.close()
        if linha is None:
            return None
        return Produto(id=linha["id"], nome=linha["nome"], preco=float(linha["preco"]))

    def atualizar(self, produto: Produto) -> bool:
        cursor = self.conexao.cursor()
        cursor.execute(
            "UPDATE produtos SET nome = %s, preco = %s WHERE id = %s",
            (produto.nome, produto.preco, produto.id),
        )
        self.conexao.commit()
        afetados = cursor.rowcount > 0
        cursor.close()
        return afetados

    def remover(self, id_produto: int) -> bool:
        cursor = self.conexao.cursor()
        cursor.execute(
            "DELETE FROM produtos WHERE id = %s",
            (id_produto,),
        )
        self.conexao.commit()
        afetados = cursor.rowcount > 0
        cursor.close()
        return afetados
